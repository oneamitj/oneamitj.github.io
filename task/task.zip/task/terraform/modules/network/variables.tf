variable "project_name" {
  description = "Project name used for resource naming"
  type        = string
  default     = "myproject"
}

variable "environment" {
  description = "Environment name (dev, prod, etc.)"
  type        = string
  default     = "dev"
}

variable "vpc_cidr" {
  description = "CIDR block for the VPC"
  type        = string
  default     = "10.0.0.0/16"
}

variable "azs" {
  description = "List of availability zones"
  type        = list(string)
  default     = ["us-east-1a", "us-east-1b"]
}

variable "public_subnet_cidrs" {
  description = "CIDR blocks for public subnets (one per AZ)"
  type        = list(string)
  default     = ["10.0.1.0/24", "10.0.2.0/24"]
}

variable "private_subnet_cidrs" {
  description = "CIDR blocks for private subnets (one per AZ)"
  type        = list(string)
  default     = ["10.0.101.0/24", "10.0.102.0/24"]
}

# NAT Gateway mode:
#   0 = no NAT gateway
#   1 = single NAT gateway (shared across all private subnets)
#   2 = one NAT gateway per AZ/public subnet
variable "nat_gateway_mode" {
  description = "NAT Gateway mode: 0 = none, 1 = single, 2 = one per AZ"
  type        = number
  default     = 0

  validation {
    condition     = contains([0, 1, 2], var.nat_gateway_mode)
    error_message = "nat_gateway_mode must be 0, 1, or 2."
  }
}
