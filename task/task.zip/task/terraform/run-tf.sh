#!/usr/bin/env bash
set -euo pipefail

usage() {
  echo "Usage: $0 --dev|--prod <terraform commands and args>"
  echo ""
  echo "Examples:"
  echo "  $0 --dev init"
  echo "  $0 --dev plan"
  echo "  $0 --prod apply -auto-approve"
  echo "  $0 --dev destroy"
  exit 1
}

[[ $# -lt 2 ]] && usage

case "$1" in
  --dev)  ENV_DIR="env/dev"  ;;
  --prod) ENV_DIR="env/prod" ;;
  *)      echo "Error: first argument must be --dev or --prod"; usage ;;
esac
shift

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

terraform -chdir="${SCRIPT_DIR}/${ENV_DIR}" "$@"
